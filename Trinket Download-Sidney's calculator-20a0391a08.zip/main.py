import math
adition = "a"
subtraction = "b"
multiplication = "c"
division = "d"
root = "e"
power = "f"

while True:
  answer = input("What math problem would you like to solve? a = addition, b = subtraction, c = multiplication, d = division, e = square root, f = raise to the power of 2. ")
  if answer != "a" and answer != "b" and answer != "c" and answer != "d" and answer != "e" and answer != "f":
        print('inavlid answer')
        print('')
        
  elif answer == "a":
    while True:
      try:
         num1 = int(input('What is the first number? '))
         break
      except:
         print('Please choose an integer')
    while True:
      try:
         num2 = int(input('What is the second number? '))
         break
      except:
         print('Please choose an integer')
           
    
    print('The sum of the two numbers is: ' + str(int(num1) + int(num2)))
    print('')
    
  elif answer == "b":
    while True:
      try:
         num1 = int(input('What is the first number? '))
         break
      except:
         print('Please choose an integer')
    while True:
      try:
         num2 = int(input('What is the second number? '))
         break
      except:
         print('Please choose an integer')
         
    print('The difference of the two numbers is: ' + str(int(num1) - int(num2)))
    print('')
        
  elif answer == "c":
    while True:
      try:
        num1 = int(input('What is the first number? '))
        break
      except:
        print('Please choose an integer')
    while True:
      try:
        num2 = int(input('What is the second number '))
        break
      except:
        print('Please choose an integer')
         
    print('The product of the two numbers is: ' + str(int(num1) * int(num2)))
    print('')
    
  elif answer == "d":
        while True:
          try:
            num1 = int(input('What is the first number? '))
            break
          except:
            print('Please choose an integer')
        while True:
          try:
            num2 = int(input('What is the second number? '))
            break
          except:
            print('Please choose an integer')
        print('The result of the two numbers is: ' + str(int(num1) / int(num2)))
        print('')
  elif answer == "e":
       while True:
         try:
            num = int(input('Enter a number to calculate the square root: '))
            break
         except:
           print('Please choose an integer')
       print('The square root is %f '%(math.sqrt(num)) )
       print('')
  elif answer == "f":
    while True:
      try:
        num = int(input('Enter the number you would like to raise '))
        break
      except:
        print('Please enter an integer')
    print('The power is %d' %(math.pow(num,2)) )
    print('')